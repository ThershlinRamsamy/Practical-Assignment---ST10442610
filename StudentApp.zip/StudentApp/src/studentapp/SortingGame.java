
package studentapp;

import java.util.Scanner;
import java.util.Arrays;

public class SortingGame {
    // Instance variables: an array of numbers and a scanner for user input
    private final int[] numbers;
    private final Scanner scanner;

    // Constructor initializes the numbers array and scanner
    public SortingGame() {
        numbers = new int[]{5, 3, 8, 6, 2, 7, 4, 1}; // Predefined array of numbers
        scanner = new Scanner(System.in); // Scanner for user input
    }

    // Method to start the sorting game
    public void start() {
        System.out.println("Welcome to the Number Sorting Game!");
        System.out.println("Original array: " + Arrays.toString(numbers));
        System.out.println("Choose sorting algorithm:");
        System.out.println("1. Bubble Sort");
        System.out.println("2. Insertion Sort");

        int choice = scanner.nextInt(); // Read user's choice
        switch (choice) {
            case 1 -> bubbleSort(numbers); // Call bubbleSort method if choice is 1
            case 2 -> insertionSort(numbers); // Call insertionSort method if choice is 2
            default -> {
                System.out.println("Invalid choice."); // Handle invalid choices
                return;
            }
        }

        // Display the sorted array
        System.out.println("Sorted array: " + Arrays.toString(numbers));
    }

    // Bubble Sort algorithm - Learned from lectures on Sorting Algorithms
    void bubbleSort(int[] array) {
        int n = array.length;
        for (int i = 0; i < n - 1; i++) { // Outer loop
            for (int j = 0; j < n - 1 - i; j++) { // Inner loop
                if (array[j] > array[j + 1]) { // Swap if the current element is greater than the next element
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }
    }

    // Insertion Sort algorithm - Learned from lectures on Sorting Algorithms
    void insertionSort(int[] array) {
        int n = array.length;
        for (int i = 1; i < n; i++) { // Loop through each element in the array
            int key = array[i];
            int j = i - 1;
            while (j >= 0 && array[j] > key) { // Shift elements greater than key to the right
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = key; // Insert the key in its correct position
        }
    }
}
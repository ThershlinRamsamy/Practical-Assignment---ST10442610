
package studentapp;

import java.util.ArrayList;
import java.util.Scanner;

public class Student {
    // Declare private instance variables - Information Hiding concept from OOP lecture
    private String id;
    private String name;
    private int age;
    private String email;
    private String course;

    //Getters
 
    // Static variables to hold students and scanner instance
    static final ArrayList<Student> students = new ArrayList<>();
    private static final Scanner scanner = new Scanner(System.in);

    // Constructor to initialize Student objects - Constructor concept from OOP lecture
    public Student(String id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

   public String getName() {
        return name;
    }
    
    public int getAge() {
        return age;
    }
    
    public String getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }
    // Override toString method to display student details - Learned in lecture on Method Overriding
  
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Age: " + age + ", Email: " + email + ", Course: " + course;
    }

    // Method to save a student - Uses Scanner and ArrayList
    public static void SaveStudent(String s001, String john_Doe, int par, String johnexamplecom, String math) {
        System.out.print("Enter student ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();
        int age = 0;
        while (true) {
            System.out.print("Enter student age: ");
            try {
                age = Integer.parseInt(scanner.nextLine());
                if (age >= 16) break;
                else System.out.println("Age must be 16 or older. Please try again.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        System.out.print("Enter student email: ");
        String email = scanner.nextLine();
        System.out.print("Enter student course: ");
        String course = scanner.nextLine();

        // Adding new student to the ArrayList
        students.add(new Student(id, name, age, email, course));
        System.out.println("Student captured successfully!");
    }

    // Method to search for a student by ID
    public static void SearchStudent() {
        System.out.print("Enter student ID to search: ");
        String id = scanner.nextLine();
        for (Student student : students) {
            if (student.getId().equals(id)) {
                System.out.println(student);
                return;
            }
        }
        System.out.println("Student not found.");
    }

    // Method to delete a student by ID
    public static void DeleteStudent() {
        System.out.print("Enter student ID to delete: ");
        String id = scanner.nextLine();
        for (Student student : students) {
            if (student.getId().equals(id)) {
                students.remove(student);
                System.out.println("Student deleted successfully!");
                return;
            }
        }
        System.out.println("Student not found.");
    }

    // Method to print a report of all students
    public static void StudentReport() {
        if (students.isEmpty()) {
            System.out.println("No students to display.");
        } else {
            for (Student student : students) {
                System.out.println(student);
            }
        }
    }

    // Method to exit the application
    public static void ExitStudentApplication() {
        System.exit(0);
    }

    // Method to get the shared Scanner instance - Resource Sharing concept from StackOverflow
    public static Scanner getScanner() {
        return scanner;
    }
}


package studentapp;


public class StudentApp {

public static void main(String[] args) {
        // Obtains a shared Scanner object from the Student class
        java.util.Scanner scanner = Student.getScanner();
        
        // Infinite loop to continuously prompt the user for an action
        while (true) {
            // Displaying the main menu options
            System.out.println("STUDENT MANAGEMENT APPLICATION");
            System.out.println("-----------------------------");
            System.out.println("1. Capture new student");
            System.out.println("2. Search for a student");
            System.out.println("3. Print student report");
            System.out.println("4. Delete a student");
            System.out.println("5. Exit Application");
            System.out.println("6. Play Sorting Game"); // question 2
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            
            switch (choice) {
                case 1 -> Student.SaveStudent("S001", "John Doe", 20, "john@example.com", "Math"); // Sample student data
                case 2 -> Student.SearchStudent();
                case 3 -> Student.StudentReport();
                case 4 -> Student.DeleteStudent();
                case 5 -> Student.ExitStudentApplication();
                case 6 -> {
                    // Create an instance of the SortingGame and start the game
                    // Object-Oriented Programming and Class Instantiation - Lecture Reference
                    SortingGame game = new SortingGame();
                    game.start();
                }
                default -> System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
// QUESTION 2
package studentapp;

import static org.junit.Assert.*; // Import assertion methods from JUnit
import org.junit.Before; // Import the Before annotation from JUnit
import org.junit.Test; // Import the Test annotation from JUnit

public class SortingGameTest {
    private SortingGame game; // Instance variable for the SortingGame class

    // Setup method to initialize the SortingGame instance before each test
    @Before
    public void setUp() {
        game = new SortingGame(); // Initialize the SortingGame object
    }

    // Test method for Bubble Sort algorithm
    @Test
    public void testBubbleSort() {
        int[] array = {5, 3, 8, 6, 2, 7, 4, 1}; // Array to be sorted
        game.bubbleSort(array); // Call bubbleSort method on the array
        assertArrayEquals(new int[]{1, 2, 3, 4, 5, 6, 7, 8}, array); // Check if the array is sorted correctly
    }

    // Test method for Insertion Sort algorithm
    @Test
    public void testInsertionSort() {
        int[] array = {5, 3, 8, 6, 2, 7, 4, 1}; // Array to be sorted
        game.insertionSort(array); // Call insertionSort method on the array
        assertArrayEquals(new int[]{1, 2, 3, 4, 5, 6, 7, 8}, array); // Check if the array is sorted correctly
    }
}

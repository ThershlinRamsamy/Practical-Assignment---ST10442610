package studentapp;

import org.junit.Test;
import static org.junit.Assert.*;

public class StudentTest {
    
    public StudentTest() {
    }

    @Test
    public void testSaveStudent() {
        Student student = new Student("12345", "John Doe", 20, "john.doe@example.com", "CS101");
        Student.students.add(student);
        assertEquals(1, Student.students.size());
        assertEquals("John Doe", Student.students.get(0).getName());
        assertEquals(20, Student.students.get(0).getAge());
        assertEquals("12345", Student.students.get(0).getId());
        assertEquals("john.doe@example.com", Student.students.get(0).getEmail());
        assertEquals("CS101", Student.students.get(0).getCourse());
    }
    
    @Test
    public void testSearchStudent() {
        Student student = new Student("54321", "Jane Doe", 22, "jane.doe@example.com", "CS102");
        Student.students.add(student);
        Student foundStudent = null;
        for (Student s : Student.students) {
            if (s.getId().equals("54321")) {
                foundStudent = s;
                break;
            }
        }
        assertNotNull(foundStudent);
        assertEquals("Jane Doe", foundStudent.getName());
        assertEquals(22, foundStudent.getAge());
        assertEquals("54321", foundStudent.getId());
        assertEquals("jane.doe@example.com", foundStudent.getEmail());
        assertEquals("CS102", foundStudent.getCourse());
    }
    
    @Test
    public void testSearchStudent_StudentNotFound() {
        Student foundStudent = null;
        for (Student s : Student.students) {
            if (s.getId().equals("99999")) {
                foundStudent = s;
                break;
            }
        }
        assertNull(foundStudent);
    }
    
    @Test
    public void testDeleteStudent() {
        Student student = new Student("67890", "Mark Smith", 23, "mark.smith@example.com", "CS103");
        Student.students.add(student);
        Student.students.removeIf(s -> s.getId().equals("67890"));
        assertEquals(0, Student.students.size());
    }
    
    @Test
    public void testDeleteStudent_StudentNotFound() {
        int initialSize = Student.students.size();
        Student.students.removeIf(s -> s.getId().equals("99999"));
        assertEquals(initialSize, Student.students.size());
    }
    
    @Test
    public void testStudentAge_StudentAgeValid() {
        int age = 18;
        assertTrue(age >= 16);
    }
    
    @Test
    public void testStudentAge_StudentAgeInvalid() {
        int age = 15;
        assertFalse(age >= 16);
    }
    
    @Test
    public void testStudentAge_StudentAgeInvalidCharacter() {
        String ageStr = "abc";
        try {
            int age = Integer.parseInt(ageStr);
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Test passes
        }
    }

}

